import './NotFound.css'
import Navigation from './Navigation';

const NotFound = () => {
  return (
    <div className='notfound'>
            <img src="logo.webp" alt="Strona Główna" />
    </div>
  );
}

export default NotFound;