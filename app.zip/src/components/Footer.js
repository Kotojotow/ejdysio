import React from 'react';

import './Footer.css';

const Footer = () => {
  return (
    <footer>
      <p>© 2024 ejdys.io Wszelkie prawa zastrzeżone.</p>
      {/* Dodaj więcej informacji w stopce według potrzeb */}
    </footer>
  );
}

export default Footer;