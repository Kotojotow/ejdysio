const UstawieniaGrafiku = () => {
    return (
        <div className="ustawieniaGrafiku">

        </div>
    );
}

export default UstawieniaGrafiku;