class employee {
    constructor(name, ){
        this.name = name;
        this.shifts = 2;
    }
    shiftChange(shift){
        this.shifts = shift; 
    }
}